#!/usr/bin/env bash

cd ~/dnscrypt && python3 generate-domains-blocklist.py -o blocklist.txt && exit
